const Servidor = require("./Servidor");

const servidor = new Servidor();
servidor.iniciar();