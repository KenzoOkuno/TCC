SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- Criar o banco de dados
CREATE SCHEMA IF NOT EXISTS `tccteste1` DEFAULT CHARACTER SET utf8mb4;
USE `tccteste1`;

-- Criar a tabela de Cargos
CREATE TABLE IF NOT EXISTS `cargo` (
  `idCargo` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nomeCargo` VARCHAR(64) NOT NULL,
  PRIMARY KEY (`idCargo`)
) ENGINE = InnoDB AUTO_INCREMENT = 1 DEFAULT CHARACTER SET = utf8;

-- Criar a tabela de Funcionários
CREATE TABLE IF NOT EXISTS `funcionario` (
  `idFuncionario` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `cargo_idCargo` INT UNSIGNED NOT NULL,
  `nomeFuncionario` VARCHAR(128) NOT NULL,
  `emailFuncionario` VARCHAR(64) NOT NULL,
  `senhaFuncionario` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`idFuncionario`),
  FOREIGN KEY (`cargo_idCargo`) REFERENCES `cargo` (`idCargo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB AUTO_INCREMENT = 1 DEFAULT CHARACTER SET = utf8;

-- Criar a tabela de Visitantes (mantém apenas nome e RG)
CREATE TABLE IF NOT EXISTS `visitante` (
  `idVisitante` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(128) NOT NULL,
  `rg` VARCHAR(20) NOT NULL UNIQUE,
  PRIMARY KEY (`idVisitante`)
) ENGINE = InnoDB AUTO_INCREMENT = 1 DEFAULT CHARACTER SET = utf8;

-- Criar a tabela de Registro (onde ficam os dados das visitas)
CREATE TABLE IF NOT EXISTS `registro` (
  `idRegistro` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `visitante_idVisitante` INT UNSIGNED NOT NULL,
  `dataVisita` DATE NOT NULL,
  `empresa` VARCHAR(128) NULL DEFAULT NULL,
  `origem` VARCHAR(128) NULL DEFAULT NULL,
  `horarioEntrada` TIME NOT NULL,
  `horarioSaida` TIME NULL DEFAULT NULL,
  `registradoPor_idFuncionario` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`idRegistro`),
  FOREIGN KEY (`visitante_idVisitante`) REFERENCES `visitante` (`idVisitante`) ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (`registradoPor_idFuncionario`) REFERENCES `funcionario` (`idFuncionario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB AUTO_INCREMENT = 1 DEFAULT CHARACTER SET = utf8;

-- Garantir que os AUTO_INCREMENT sempre comecem em 1
ALTER TABLE `cargo` AUTO_INCREMENT = 1;
ALTER TABLE `funcionario` AUTO_INCREMENT = 1;
ALTER TABLE `visitante` AUTO_INCREMENT = 1;
ALTER TABLE `registro` AUTO_INCREMENT = 1;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
