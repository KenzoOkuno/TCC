const Banco = require("./banco");

module.exports = class Registro {
    constructor() {
        this._idRegistro = null;
        this._visitante_idVisitante = null;
        this._dataVisita = null;
        this._empresa = null;
        this._origem = null;
        this._horarioEntrada = null;
        this._horarioSaida = null;
        this._registradoPor_idFuncionario = null;
    }

    // Criar um novo registro de visita utilizando os valores enviados
    create = async () => {
        if (
            this.visitante_idVisitante === undefined ||
            this.dataVisita === undefined ||
            this.empresa === undefined ||
            this.origem === undefined ||
            this.horarioEntrada === undefined ||
            this.registradoPor_idFuncionario === undefined
        ) {
            console.log("Erro: Parâmetros inválidos:", {
                visitante_idVisitante: this.visitante_idVisitante,
                dataVisita: this.dataVisita,
                empresa: this.empresa,
                origem: this.origem,
                horarioEntrada: this.horarioEntrada,
                horarioSaida: this.horarioSaida,
                registradoPor_idFuncionario: this.registradoPor_idFuncionario,
            });
            return false;
        }

        const SQL = "INSERT INTO registro (visitante_idVisitante, dataVisita, empresa, origem, horarioEntrada, horarioSaida, registradoPor_idFuncionario) VALUES (?, ?, ?, ?, ?, ?, ?);";
        try {
            const [resultado] = await Banco.getConexao().promise().execute(SQL, [
                this.visitante_idVisitante, 
                this.dataVisita,
                this.empresa, 
                this.origem, 
                this.horarioEntrada,
                this.horarioSaida, 
                this.registradoPor_idFuncionario
            ]);
            this.idRegistro = resultado.insertId;
            return resultado.affectedRows > 0;
        } catch (error) {
            console.log(error);
            return false;
        }
    };

    // Atualizar um registro de visita
    update = async () => {
        const SQL = `
            UPDATE registro 
            SET visitante_idVisitante = ?, dataVisita = ?, empresa = ?, origem = ?, 
                horarioEntrada = ?, horarioSaida = ?, registradoPor_idFuncionario = ? 
            WHERE idRegistro = ?;
        `;
        try {
            const [resultado] = await Banco.getConexao().promise().execute(SQL, [
                this.visitante_idVisitante,
                this.dataVisita,
                this.empresa,
                this.origem,
                this.horarioEntrada,
                this.horarioSaida,
                this.registradoPor_idFuncionario,
                this.idRegistro
            ]);
            return resultado.affectedRows > 0;
        } catch (error) {
            console.log(error);
            return false;
        }
    };

    // Ler todos os registros de visitas
    readAll = async () => {
        const SQL = "SELECT * FROM registro;";
        try {
            const [resultado] = await Banco.getConexao().promise().execute(SQL, []);
            return resultado;
        } catch (error) {
            console.log(error);
            return [];
        }
    };

    // Ler um registro específico pelo ID
    readById = async () => {
        const SQL = "SELECT * FROM registro WHERE idRegistro = ?;";
        try {
            const [resultado] = await Banco.getConexao().promise().execute(SQL, [this.idRegistro]);
            return resultado;
        } catch (error) {
            console.log(error);
            return [];
        }
    };

    // Deletar um registro de visita
    delete = async () => {
        const SQL = "DELETE FROM registro WHERE idRegistro = ?;";
        try {
            const [resultado] = await Banco.getConexao().promise().execute(SQL, [this.idRegistro]);
            return resultado.affectedRows > 0;
        } catch (error) {
            console.log(error);
            return false;
        }
    };

    // Getters and Setters
    get idRegistro() { return this._idRegistro; }
    set idRegistro(value) { this._idRegistro = value; }

    get visitante_idVisitante() { return this._visitante_idVisitante; }
    set visitante_idVisitante(value) { this._visitante_idVisitante = value; }

    get dataVisita() { return this._dataVisita; }
    set dataVisita(value) { this._dataVisita = value; }

    get empresa() { return this._empresa; }
    set empresa(value) { this._empresa = value; }

    get origem() { return this._origem; }
    set origem(value) { this._origem = value; }

    get horarioEntrada() { return this._horarioEntrada; }
    set horarioEntrada(value) { this._horarioEntrada = value; }

    get horarioSaida() { return this._horarioSaida; }
    set horarioSaida(value) { this._horarioSaida = value; }

    get registradoPor_idFuncionario() { return this._registradoPor_idFuncionario; }
    set registradoPor_idFuncionario(value) { this._registradoPor_idFuncionario = value; }
};
